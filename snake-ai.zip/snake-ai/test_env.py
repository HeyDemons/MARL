import pygame
import random
from snake_env import SnakeEnv, Direction # 从您的文件中导入SnakeEnv类

def run_test():
    """
    运行Snake环境测试的函数。
    """
    # 初始化环境，这里我们指定生成10个障碍物
    env = SnakeEnv(num_obstacles=10)
    
    # 重置环境并获取初始状态
    state = env.reset()
    
    running = True
    # 主循环
    while running:
        # 1. 首先渲染画面
        # 在第一次循环时，这行代码会负责初始化Pygame并创建窗口
        env.render(fps=15) 
        
        # 2. 现在窗口已经初始化，可以安全地处理事件了
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # 3. 更新游戏状态
        # 随机选择一个动作
        action = random.randint(0, 3) 
        
        # 执行动作，并获取返回信息
        next_state, reward, done, info = env.step(action)
        
        # 4. 检查游戏是否结束
        if done:
            print(f"游戏结束! 最终得分: {info['score']}")
            print("将在2秒后重新开始...")
            pygame.time.delay(2000) # 暂停2秒
            
            # 重置环境，开始新的一局
            env.reset()

    # 关闭环境
    env.close()
    print("测试程序已退出。")

if __name__ == '__main__':
    run_test()