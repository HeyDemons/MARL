import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque
from model import ActorCritic
from config import *
import torch.nn.functional as F
class Memory:
    """经验回放缓冲区"""
    def __init__(self, max_size=MEMORY_SIZE):
        self.states = []
        self.actions = []
        self.rewards = []
        self.next_states = []
        self.dones = []
        self.action_probs = []
        
    def add(self, state, action, reward, next_state, done, action_prob):
        self.states.append(state)
        self.actions.append(action)
        self.rewards.append(reward)
        self.next_states.append(next_state)
        self.dones.append(done)
        self.action_probs.append(action_prob)
    
    def clear(self):
        self.states = []
        self.actions = []
        self.rewards = []
        self.next_states = []
        self.dones = []
        self.action_probs = []
    
    def size(self):
        return len(self.states)

class PPOAgent:
    """PPO 强化学习智能体"""
    def __init__(self, input_dim=INPUT_DIM, hidden_dim=HIDDEN_DIM, output_dim=OUTPUT_DIM):
        self.policy = ActorCritic(input_dim, hidden_dim, output_dim)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=LEARNING_RATE)
        self.memory = Memory()
        
        # 训练参数
        self.gamma = GAMMA
        self.ppo_clip = PPO_CLIP
        self.ppo_epochs = PPO_EPOCHS
        self.entropy_coef = ENTROPY_COEF
        self.value_coef = VALUE_COEF
        
        # 监控指标
        self.episode_rewards = []
        self.episode_lengths = []
        self.avg_rewards = deque(maxlen=100)
    
    def select_action(self, state, deterministic=False):
        """选择动作，增加前瞻功能"""
        with torch.no_grad():
            # 先使用策略网络获得动作概率
            action_probs, _ = self.policy.forward(state)
            action_probs = action_probs.squeeze()
            
            # 如果是评估模式，直接选择最高概率动作
            if deterministic:
                action = torch.argmax(action_probs).item()
                return action, action_probs[action].item()
            
            # 训练模式下，使用概率采样，但加入安全检查
            original_probs = action_probs.clone()
            
            # 创建动作的掩码，去除危险动作 (利用状态中的危险信息)
            state_array = state.squeeze().cpu().numpy()
            danger_mask = np.array([
                state_array[4],  # 上方危险
                state_array[5],  # 右方危险
                state_array[6],  # 下方危险
                state_array[7]   # 左方危险
            ])
            
            # 如果所有方向都有危险，使用原始概率
            if np.sum(danger_mask) == 4:
                dist = torch.distributions.Categorical(action_probs)
            else:
                # 否则，降低危险方向的概率
                safe_probs = action_probs.clone()
                for i, is_danger in enumerate(danger_mask):
                    if is_danger:
                        safe_probs[i] *= 0.1  # 降低危险方向的概率
                        
                # 重新归一化概率
                safe_probs = safe_probs / safe_probs.sum()
                dist = torch.distributions.Categorical(safe_probs)
                
            action = dist.sample().item()
            return action, original_probs[action].item()
    
    def compute_gae(self, rewards, values, dones, next_value, gamma=0.99, lam=0.95):
        """计算广义优势估计 (GAE)"""
        advantages = []
        gae = 0
        
        for i in reversed(range(len(rewards))):
            if i == len(rewards) - 1:
                delta = rewards[i] + gamma * next_value * (1 - dones[i]) - values[i]
            else:
                delta = rewards[i] + gamma * values[i + 1] * (1 - dones[i]) - values[i]
            
            gae = delta + gamma * lam * (1 - dones[i]) * gae
            advantages.insert(0, gae)
            
        advantages = torch.tensor(advantages, dtype=torch.float).to(DEVICE)
        return advantages
    
    def update(self):
        """使用 PPO 算法更新策略网络"""
        if self.memory.size() == 0:
            return 0, 0, 0
        
        # 将记忆中的数据转换为张量
        states = torch.cat(self.memory.states).to(DEVICE)
        actions = torch.tensor(self.memory.actions, dtype=torch.long).to(DEVICE)
        rewards = torch.tensor(self.memory.rewards, dtype=torch.float).to(DEVICE)
        dones = torch.tensor(self.memory.dones, dtype=torch.float).to(DEVICE)
        old_probs = torch.tensor(self.memory.action_probs, dtype=torch.float).to(DEVICE)
        
        # 计算折现回报和优势
        with torch.no_grad():
            _, values = self.policy(states)
            values = values.squeeze()
            
            if self.memory.next_states[-1] is not None:
                _, next_value = self.policy(self.memory.next_states[-1])
                next_value = next_value.item()
            else:
                next_value = 0
            
            # 计算广义优势估计
            advantages = self.compute_gae(rewards.tolist(), values.tolist(), dones.tolist(), next_value)
            returns = advantages + values
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        # PPO 更新循环
        total_loss = 0
        total_policy_loss = 0
        total_value_loss = 0
        total_entropy = 0
        
        for _ in range(self.ppo_epochs):
            # 获取当前策略的动作概率和状态价值
            action_probs, values = self.policy(states)
            values = values.squeeze()
            
            # 计算当前动作的概率
            dist = torch.distributions.Categorical(action_probs)
            new_probs = dist.log_prob(actions)
            entropy = dist.entropy().mean()
            
            # 计算 PPO 比率和裁剪后的目标
            ratio = torch.exp(new_probs - torch.log(old_probs))
            surr1 = ratio * advantages
            surr2 = torch.clamp(ratio, 1.0 - self.ppo_clip, 1.0 + self.ppo_clip) * advantages
            
            # 策略损失、价值损失和熵损失
            policy_loss = -torch.min(surr1, surr2).mean()
            value_loss = F.mse_loss(values, returns)
            
            # 总损失
            loss = policy_loss + self.value_coef * value_loss - self.entropy_coef * entropy
            
            # 更新网络
            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.policy.parameters(), MAX_GRAD_NORM)
            self.optimizer.step()
            
            total_loss += loss.item()
            total_policy_loss += policy_loss.item()
            total_value_loss += value_loss.item()
            total_entropy += entropy.item()
        
        # 清空记忆
        self.memory.clear()
        
        return total_loss / self.ppo_epochs, total_policy_loss / self.ppo_epochs, total_value_loss / self.ppo_epochs
    
    def save(self, path):
        """保存模型"""
        torch.save(self.policy.state_dict(), path)
    
    def load(self, path):
        """加载模型"""
        self.policy.load_state_dict(torch.load(path, map_location=DEVICE))
        self.policy.to(DEVICE)