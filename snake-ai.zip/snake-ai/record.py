# record_video.py

# 1. 设置环境变量，必须在导入pygame之前完成！
# 这会告诉Pygame使用一个虚拟的、在内存中运行的显示驱动
import os
os.environ["SDL_VIDEODRIVER"] = "dummy"

import pygame
import numpy as np
from moviepy.editor import ImageSequenceClip
import tempfile

# 导入您的环境和其他必要的类
from snake_env import SnakeEnv, Direction
from config import * # 确保您的config文件路径正确

# 2. 创建一个虚拟Agent用于测试
# 在实际使用中，您应该导入并使用您自己训练的Agent
class RandomAgent:
    """一个只会执行随机动作的Agent，用于演示。"""
    def select_action(self, state, deterministic=False):
        # 随机选择一个动作 (0:上, 1:右, 2:下, 3:左)
        action = np.random.randint(0, 4)
        # 返回动作和空的日志概率（如果您的模型需要）
        return action, None

def create_video_buffer(env, agent, episodes=3, max_steps=500, fps=15):
    """
    在无头模式下运行游戏，并将画面录制为MP4视频。
    """
    print("开始录制视频...")
    
    frames = []
    
    for episode in range(episodes):
        print(f"  - 正在录制第 {episode + 1}/{episodes} 幕...")
        state = env.reset()
        done = False
        step = 0
        
        # 确保在无头模式下，Pygame已经初始化
        if env.display is None:
            env.render() # 第一次调用render会初始化pygame
            
        while not done and step < max_steps:
            # 渲染环境到内存中的surface
            env.render()
            pygame_surface = env.display
            
            # 将 PyGame surface 转换为 numpy 数组
            frame = pygame.surfarray.array3d(pygame_surface)
            # surfarray输出的格式是(width, height, channels)，我们需要(height, width, channels)
            # moviepy期望的格式是(height, width, channels)
            # pygame的坐标系(0,0)在左上角，x向右，y向下，因此转置是必要的
            frame = frame.transpose([1, 0, 2])
            frames.append(frame)
            
            # 从Agent获取动作
            # 注意：这里的 state 是 tensor，需要根据您Agent的输入进行调整
            # 对于随机Agent，我们不需要state
            action, _ = agent.select_action(state, deterministic=True)
            
            # 执行动作
            state, reward, done, info = env.step(action)
            step += 1
        
        print(f"    第 {episode + 1} 幕结束，得分: {info.get('score', 0)}")

    # 录制结束后关闭环境
    env.close()
    
    if not frames:
        print("没有录制到任何帧，无法创建视频。")
        return None

    # 创建视频剪辑
    print("\n正在将所有帧合成为视频文件...")
    clip = ImageSequenceClip(frames, fps=fps)
    
    # 确保'results'目录存在
    results_dir = 'results'
    os.makedirs(results_dir, exist_ok=True)
    
    video_path = os.path.join(results_dir, 'snake_ai_simulation.mp4')
    
    # 写入视频文件，使用'libx264'编码器获得更好的兼容性
    clip.write_videofile(video_path, codec='libx264')
    
    print(f"\n视频成功保存到: {video_path}")
    return video_path

if __name__ == '__main__':
    # 初始化环境和Agent
    # 您可以调整障碍物数量等参数
    env = SnakeEnv(num_obstacles=10) 
    
    # 在这里替换为您自己训练的Agent
    agent = RandomAgent() 
    
    # 调用函数开始录制
    create_video_buffer(env, agent, episodes=3)