import torch
import torch.nn as nn
import torch.nn.functional as F
from config import *

class ActorCritic(nn.Module):
    """Actor-Critic 网络模型"""
    def __init__(self, input_dim=INPUT_DIM, hidden_dim=HIDDEN_DIM, output_dim=OUTPUT_DIM):
        super(ActorCritic, self).__init__()
        
        # 共享特征提取层
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        
        # Actor 网络（策略网络）
        self.actor_fc = nn.Linear(hidden_dim, hidden_dim)
        self.actor_out = nn.Linear(hidden_dim, output_dim)
        
        # Critic 网络（价值网络）
        self.critic_fc = nn.Linear(hidden_dim, hidden_dim)
        self.critic_out = nn.Linear(hidden_dim, 1)
        
        self.to(DEVICE)
    
    def forward(self, x):
        """前向传播"""
        if not isinstance(x, torch.Tensor):
            x = torch.FloatTensor(x).to(DEVICE)
            
        x = F.relu(self.fc1(x))
        
        # Actor 输出（动作概率）
        actor_hidden = F.relu(self.actor_fc(x))
        action_probs = F.softmax(self.actor_out(actor_hidden), dim=-1)
        
        # Critic 输出（状态价值）
        critic_hidden = F.relu(self.critic_fc(x))
        state_values = self.critic_out(critic_hidden)
        
        return action_probs, state_values
    
    def get_action(self, state, deterministic=False):
        """根据状态选择动作"""
        action_probs, _ = self.forward(state)
        
        if deterministic:
            # 确定性策略：选择概率最高的动作
            action = torch.argmax(action_probs, dim=-1)
        else:
            # 随机策略：根据概率采样动作
            dist = torch.distributions.Categorical(action_probs)
            action = dist.sample()
            
        return action.item(), action_probs