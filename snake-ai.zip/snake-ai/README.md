# 基于深度强化学习的贪吃蛇 AI

这个项目使用 PyTorch 和 PPO（近端策略优化）算法来训练 AI 玩贪吃蛇游戏。通过深度强化学习，AI 能够自主学习高效的贪吃蛇策略。

## 项目结构

```
snake-ai/
│
├── main.py             # 主程序入口
├── snake_env.py        # 贪吃蛇游戏环境
├── model.py            # 神经网络模型
├── agent.py            # PPO 强化学习智能体
├── train.py            # 训练和测试脚本
├── utils.py            # 可视化和辅助工具
├── config.py           # 配置参数
│
├── models/             # 保存训练好的模型
└── results/            # 保存训练结果和可视化
```

## 特点

- 基于 PyGame 构建的可视化贪吃蛇游戏环境
- 使用 PPO 策略梯度算法优化智能体行为
- Actor-Critic 网络架构，同时学习策略和价值函数
- 基于食物位置、危险区域和当前方向的状态表示
- 精心设计的奖励函数，鼓励蛇寻找食物并避免碰撞
- 训练过程可视化监控与分析

## 安装依赖

```bash
pip install torch numpy pygame matplotlib tqdm moviepy
```

## 如何使用

### 训练智能体

```bash
python main.py --mode train
```

训练过程将会保存最佳模型和学习曲线。

### 测试智能体

```bash
python main.py --mode test --model models/snake_best_model.pt --episodes 5
```

### 生成演示视频

```bash
python main.py --mode video --model models/snake_best_model.pt --episodes 5
```

## 状态表示

智能体观察到的状态包含 11 个特征：
- 蛇头相对于食物的方向（4 维向量）
- 蛇头周围四个方向是否有障碍（4 维向量）
- 当前移动方向（4 维 one-hot 编码，只使用了 3 维）

## 奖励设计

- 获取食物: +10.0
- 游戏结束 (碰撞): -10.0
- 每一步: -0.01 (鼓励更快完成任务)
- 接近食物: +0.1
- 远离食物: -0.1

## 训练结果

训练过程中，智能体会逐渐学会：
1. 避开墙壁和自身
2. 高效寻找食物
3. 在空间有限的情况下规划路径

学习曲线展示了智能体在训练过程中的奖励和游戏长度变化。

## 参数配置

可以在 `config.py` 中修改各种参数，包括：
- 游戏设置（网格大小、初始蛇长度）
- 神经网络架构（隐藏层大小）
- PPO 训练参数（学习率、折扣因子、剪切系数）
- 奖励权重