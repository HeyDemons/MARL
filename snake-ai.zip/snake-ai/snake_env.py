import pygame
import numpy as np
import random
from enum import Enum
import torch
# Make sure you have a config.py file or define these constants here
# For example:
# GRID_SIZE = 10
# CELL_SIZE = 20
# INIT_SNAKE_LENGTH = 3
# REWARD_STEP = -0.01
# REWARD_SURVIVAL = 0.001
# REWARD_DEATH = -1.0
# REWARD_FOOD = 1.0
# REWARD_CLOSER = 0.02
# REWARD_FARTHER = -0.03
# DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
from config import *


class Direction(Enum):
    UP = 0
    RIGHT = 1
    DOWN = 2
    LEFT = 3

class SnakeEnv:
    def __init__(self, grid_size=GRID_SIZE, cell_size=CELL_SIZE, init_length=INIT_SNAKE_LENGTH, num_obstacles=5): # 新增: 障碍物数量参数
        self.grid_size = grid_size
        self.cell_size = cell_size
        self.init_length = init_length
        self.num_obstacles = num_obstacles  # 新增: 障碍物数量
        self.obstacles = []                 # 新增: 存储障碍物位置的列表
        self.display = None
        
        # PyGame 相关
        self.width = self.grid_size * self.cell_size
        self.height = self.grid_size * self.cell_size
        self.clock = None
        self.font = None
        self.speed = 10
        
        # 游戏状态
        self.snake = []
        self.direction = None
        self.food = None
        self.score = 0
        self.steps = 0
        self.max_steps = self.grid_size * self.grid_size * 2
        
        # 动作映射
        self.actions = [Direction.UP, Direction.RIGHT, Direction.DOWN, Direction.LEFT]
        
        self.reset()
    
    def init_pygame(self):
        """初始化 PyGame (仅在可视化时使用)"""
        pygame.init()
        self.display = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption('Snake AI')
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont('arial', 20)
    
    def reset(self):
        """重置游戏环境"""
        # 初始化蛇
        self.snake = []
        x = self.grid_size // 2
        y = self.grid_size // 2
        self.snake = [(x, y)]
        
        # 添加初始蛇身
        for i in range(1, self.init_length):
            self.snake.append((x, y - i))
        
        self.direction = Direction.RIGHT
        self.generate_obstacles()  # 新增: 生成障碍物
        self.generate_food()
        self.score = 0
        self.steps = 0
        
        return self.get_state()
    
    def generate_obstacles(self):
        """新增: 生成随机障碍物"""
        self.obstacles = []
        for _ in range(self.num_obstacles):
            while True:
                x = random.randint(0, self.grid_size - 1)
                y = random.randint(0, self.grid_size - 1)
                # 确保障碍物不生成在蛇身上或已有的障碍物上
                if (x, y) not in self.snake and (x, y) not in self.obstacles:
                    self.obstacles.append((x, y))
                    break

    def generate_food(self):
        """生成食物"""
        while True:
            x = random.randint(0, self.grid_size - 1)
            y = random.randint(0, self.grid_size - 1)
            # 修改: 确保食物不生成在蛇身或障碍物上
            if (x, y) not in self.snake and (x, y) not in self.obstacles:
                self.food = (x, y)
                break
    
    def get_state(self):
        """获取增强的状态表示"""
        head_x, head_y = self.snake[0]
        food_x, food_y = self.food
        
        # 蛇头相对于食物的位置
        food_up = 1 if head_y > food_y else 0
        food_right = 1 if head_x < food_x else 0
        food_down = 1 if head_y < food_y else 0
        food_left = 1 if head_x > food_x else 0
        
        # 检查四个方向是否有障碍 (墙, 蛇身, 或障碍物)
        danger_up = 1 if self.is_collision(head_x, head_y - 1) else 0
        danger_right = 1 if self.is_collision(head_x + 1, head_y) else 0
        danger_down = 1 if self.is_collision(head_x, head_y + 1) else 0
        danger_left = 1 if self.is_collision(head_x - 1, head_y) else 0
        
        # 当前方向的one-hot编码
        dir_up = 1 if self.direction == Direction.UP else 0
        dir_right = 1 if self.direction == Direction.RIGHT else 0
        dir_down = 1 if self.direction == Direction.DOWN else 0
        dir_left = 1 if self.direction == Direction.LEFT else 0
        
        # 添加食物距离特征 (曼哈顿距离的归一化值)
        food_distance = abs(head_x - food_x) + abs(head_y - food_y)
        normalized_distance = food_distance / (2 * self.grid_size)
        
        # 检查更远距离的危险 (2格远的危险)
        danger_up_2 = 1 if self.is_collision(head_x, head_y - 2) else 0
        danger_right_2 = 1 if self.is_collision(head_x + 2, head_y) else 0
        danger_down_2 = 1 if self.is_collision(head_x, head_y + 2) else 0
        danger_left_2 = 1 if self.is_collision(head_x - 2, head_y) else 0
        
        # 增加蛇身长度特征 (归一化)
        snake_length = len(self.snake) / (self.grid_size * self.grid_size)
        
        state = [
            food_up, food_right, food_down, food_left,
            danger_up, danger_right, danger_down, danger_left,
            danger_up_2, danger_right_2, danger_down_2, danger_left_2,  # 更远的危险感知
            dir_up, dir_right, dir_down, dir_left,
            normalized_distance,  # 食物距离
            snake_length  # 蛇身长度
        ]
        
        return torch.FloatTensor(state).unsqueeze(0).to(DEVICE)
    
    def is_collision(self, x, y):
        """检查给定位置是否碰撞"""
        # 检查是否撞墙
        if x < 0 or x >= self.grid_size or y < 0 or y >= self.grid_size:
            return True
        
        # 检查是否撞到自己
        if (x, y) in self.snake[1:]:
            return True
        
        # 新增: 检查是否撞到障碍物
        if (x, y) in self.obstacles:
            return True
        
        return False
    
    def get_distance_to_food(self):
        """计算蛇头到食物的曼哈顿距离"""
        head_x, head_y = self.snake[0]
        food_x, food_y = self.food
        return abs(head_x - food_x) + abs(head_y - food_y)
    
    def step(self, action_idx):
        """执行动作并返回奖励和下一个状态"""
        self.steps += 1
        prev_distance = self.get_distance_to_food()
        
        # 获取动作并更新方向
        new_direction = self.actions[action_idx]
        
        # 禁止直接回头（如果这样会导致游戏立即结束）
        if (self.direction == Direction.UP and new_direction == Direction.DOWN) or \
           (self.direction == Direction.DOWN and new_direction == Direction.UP) or \
           (self.direction == Direction.LEFT and new_direction == Direction.RIGHT) or \
           (self.direction == Direction.RIGHT and new_direction == Direction.LEFT):
            new_direction = self.direction
        
        self.direction = new_direction
        
        # 根据方向移动蛇头
        head_x, head_y = self.snake[0]
        if self.direction == Direction.UP:
            head_y -= 1
        elif self.direction == Direction.RIGHT:
            head_x += 1
        elif self.direction == Direction.DOWN:
            head_y += 1
        elif self.direction == Direction.LEFT:
            head_x -= 1
        
        # 检查碰撞
        done = False
        reward = REWARD_STEP  # 基础奖励
        
        # 添加存活奖励，长度越长存活奖励越高
        reward += REWARD_SURVIVAL * len(self.snake)
        
        if self.is_collision(head_x, head_y):
            # 根据蛇的长度动态调整死亡惩罚
            death_penalty = REWARD_DEATH * (1.0 + len(self.snake) * 0.1)
            reward = death_penalty
            done = True
        else:
            # 更新蛇头位置
            self.snake.insert(0, (head_x, head_y))
            
            # 检查是否吃到食物
            if (head_x, head_y) == self.food:
                self.score += 1
                reward = REWARD_FOOD
                self.generate_food()
            else:
                # 如果没吃到食物，移除尾巴
                self.snake.pop()
                
                # 根据与食物的距离调整奖励
                new_distance = self.get_distance_to_food()
                if new_distance < prev_distance:
                    reward += REWARD_CLOSER
                elif new_distance > prev_distance:
                    reward += REWARD_FARTHER
        
        # 超过最大步数则结束
        if self.steps >= self.max_steps:
            done = True
        
        next_state = self.get_state()
        info = {
            'score': self.score,
            'steps': self.steps
        }
        
        return next_state, reward, done, info
    
    def render(self, fps=10):
        """渲染游戏画面"""
        if self.display is None:
            self.init_pygame()
        
        self.display.fill((0, 0, 0))
        
        # 新增: 绘制障碍物
        for (x, y) in self.obstacles:
            obstacle_rect = pygame.Rect(
                x * self.cell_size,
                y * self.cell_size,
                self.cell_size, self.cell_size
            )
            pygame.draw.rect(self.display, (128, 128, 128), obstacle_rect) # 灰色障碍物

        # 绘制食物
        food_rect = pygame.Rect(
            self.food[0] * self.cell_size,
            self.food[1] * self.cell_size,
            self.cell_size, self.cell_size
        )
        pygame.draw.rect(self.display, (255, 0, 0), food_rect)
        
        # 绘制蛇
        for i, (x, y) in enumerate(self.snake):
            snake_rect = pygame.Rect(
                x * self.cell_size,
                y * self.cell_size,
                self.cell_size, self.cell_size
            )
            # 蛇头用不同颜色
            color = (0, 255, 0) if i == 0 else (0, 200, 0)
            pygame.draw.rect(self.display, color, snake_rect)
        
        # 显示分数
        score_text = self.font.render(f"Score: {self.score}", True, (255, 255, 255))
        self.display.blit(score_text, (10, 10))
        
        pygame.display.update()
        self.clock.tick(fps)
    
    def close(self):
        """关闭环境"""
        if self.display is not None:
            pygame.quit()