import torch

# 游戏参数
GRID_SIZE = 20
CELL_SIZE = 20
INIT_SNAKE_LENGTH = 3

# 训练参数
LEARNING_RATE = 0.0001
GAMMA = 0.99  # 提高到 0.995 或 0.999，更重视长期回报
PPO_CLIP = 0.2
PPO_EPOCHS = 4
BATCH_SIZE = 128
ENTROPY_COEF = 0.02  # 增加熵系数以鼓励更多探索
VALUE_COEF = 0.5
MAX_GRAD_NORM = 0.5
NUM_EPISODES = 10000
UPDATE_FREQUENCY = 20

# 经验回放
MEMORY_SIZE = 10000

# 神经网络参数
INPUT_DIM = 18  # 更新后的状态向量维度
HIDDEN_DIM = 128
OUTPUT_DIM = 4  # 动作数量：上、下、左、右

# 调整后的奖励设置
REWARD_FOOD = 20.0
REWARD_DEATH = -30.0  # 增加死亡惩罚
REWARD_STEP = -0.01
REWARD_CLOSER = 0.1
REWARD_FARTHER = -0.1
# 新增奖励 - 存活奖励
REWARD_SURVIVAL = 0.005  # 每步给予小幅存活奖励

# 设备配置
DEVICE = torch.device("mps" if torch.cuda.is_available() else "cpu")