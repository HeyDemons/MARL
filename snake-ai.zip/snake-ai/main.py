# main.py (修正版)

import argparse
import os

# ！！！注意：将所有可能导入pygame的模块从顶层移除
# 比如 SnakeEnv, train, utils 等

def main():
    parser = argparse.ArgumentParser(description='贪吃蛇 AI，支持训练、测试和视频录制')
    parser.add_argument('--mode', type=str, required=True, choices=['train', 'test', 'video'], help='运行模式')
    parser.add_argument('--model', type=str, default='models/snake_best_model.pt', help='模型文件路径')
    parser.add_argument('--episodes', type=int, default=5, help='测试或录制视频的回合数')
    args = parser.parse_args()

    if args.mode == 'train':
        print("开始训练贪吃蛇 AI...")
        # 训练通常不需要GUI，可以直接运行
        from train import train
        agent = train()
        print("训练完成！")

    elif args.mode == 'test':
        # 测试模式需要GUI，所以不进行任何特殊设置
        # 必须使用 pythonw 来运行此模式
        print(f"使用模型 {args.model} 测试贪吃蛇 AI (需要GUI窗口)...")
        from train import test
        test(model_path=args.model, episodes=args.episodes)

    elif args.mode == 'video':
        # 录制视频模式，必须设置为无头模式
        print("创建贪吃蛇 AI 演示视频（无头模式）...")
        
        # 关键修复：在导入任何pygame相关模块之前，设置环境变量
        os.environ["SDL_VIDEODRIVER"] = "dummy"
        
        # 现在再导入需要的模块
        from snake_env import SnakeEnv
        from agent import PPOAgent  # 确保这里的Agent类名正确
        from utils import create_video_buffer
        
        # 创建环境和Agent
        env = SnakeEnv()
        agent = PPOAgent()
        agent.load(args.model)
        
        # 调用录制函数
        video_path = create_video_buffer(env, agent, episodes=args.episodes)
        print(f"视频已保存至: {video_path}")

if __name__ == "__main__":
    main()