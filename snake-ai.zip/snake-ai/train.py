import torch
import numpy as np
from snake_env import SnakeEnv
from agent import PPOAgent
from utils import plot_learning_curve, create_directories
from config import *
import pygame
import time
from tqdm import tqdm

def train():
    """训练 PPO 智能体玩贪吃蛇游戏"""
    create_directories()
    
    # 创建环境和智能体
    env = SnakeEnv()
    agent = PPOAgent()
    
    best_reward = -float('inf')
    update_timestep = UPDATE_FREQUENCY
    total_timesteps = 0
    
    # 记录统计数据
    episode_rewards = []
    episode_lengths = []
    
    # 课程学习：动态调整死亡惩罚
    death_penalty_schedule = {
        0: -10.0,     # 初始值
        1000: -15.0,  # 1000 回合后
        3000: -20.0,  # 3000 回合后
        6000: -30.0   # 6000 回合后
    }
    
    # 使用 tqdm 显示训练进度条
    with tqdm(total=NUM_EPISODES, desc="Training Progress", unit="episode") as pbar:
        for episode in range(1, NUM_EPISODES + 1):
            # 根据进度调整死亡惩罚
            for ep_threshold, penalty in sorted(death_penalty_schedule.items()):
                if episode >= ep_threshold:
                    REWARD_DEATH = penalty
            
            state = env.reset()
            done = False
            episode_reward = 0
            episode_length = 0
            
            while not done:
                # 选择动作
                action, action_prob = agent.select_action(state)
                next_state, reward, done, info = env.step(action)
                
                # 存储经验
                agent.memory.add(state, action, reward, next_state, done, action_prob)
                
                # 更新状态和统计信息
                state = next_state
                episode_reward += reward
                episode_length += 1
                total_timesteps += 1
                
                # 按时间步频率更新策略
                if total_timesteps % update_timestep == 0:
                    loss, policy_loss, value_loss = agent.update()
                
                # 定期可视化 (每 500 个时间步)
                if total_timesteps % 500 == 0 and episode > 1:
                    plot_learning_curve(
                        episode_rewards, 
                        episode_lengths, 
                        title=f'Snake AI - Episode {episode}'
                    )
            
            # 记录本轮结果
            episode_rewards.append(episode_reward)
            episode_lengths.append(episode_length)
            agent.avg_rewards.append(episode_reward)
            
            # 更新进度条
            pbar.update(1)
            pbar.set_postfix({
                "score": info['score'], 
                "len": episode_length, 
                "r": f"{episode_reward:.2f}", 
                "avg_r": f"{np.mean(agent.avg_rewards):.2f}",
            })
            
            # 保存最佳模型
            if np.mean(agent.avg_rewards) > best_reward:
                best_reward = np.mean(agent.avg_rewards)
                agent.save('models/snake_best_model.pt')
    # 训练完成后保存最终模型
    agent.save('models/snake_final_model.pt')
    
    # 绘制最终学习曲线
    plot_learning_curve(
        episode_rewards, 
        episode_lengths, 
        title='Final Learning Curve'
    )
    
    return agent

def test(model_path='models/snake_best_model.pt', episodes=5):
    """测试训练好的智能体"""
    env = SnakeEnv()
    agent = PPOAgent()
    agent.load(model_path)
    
    for episode in range(episodes):
        state = env.reset()
        done = False
        total_reward = 0
        steps = 0
        
        # 初始化 PyGame
        env.init_pygame()
        
        while not done:
            env.render(fps=10)
            
            # 处理 PyGame 事件
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    env.close()
                    return
            
            # 选择动作 (使用确定性策略)
            action, _ = agent.select_action(state, deterministic=True)
            state, reward, done, info = env.step(action)
            
            total_reward += reward
            steps += 1
            
            time.sleep(0.05)  # 减慢可视化速度
        
        print(f"Episode {episode+1}: Score = {info['score']}, Steps = {steps}, Reward = {total_reward:.2f}")
        time.sleep(1)  # 回合之间的暂停
    
    env.close()