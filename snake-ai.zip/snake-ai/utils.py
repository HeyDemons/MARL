import matplotlib.pyplot as plt
import numpy as np
import torch
from IPython.display import clear_output
from config import *
import os
import pygame

def plot_learning_curve(rewards, lengths, window=100, title=''):
    """绘制学习曲线"""
    plt.figure(figsize=(12, 8))
    
    # 平滑奖励
    if len(rewards) >= window:
        avg_rewards = np.convolve(rewards, np.ones(window)/window, mode='valid')
        plt.subplot(2, 1, 1)
        plt.plot(np.arange(len(rewards)), rewards, alpha=0.5, label='Episode Reward')
        plt.plot(np.arange(window-1, len(rewards)), avg_rewards, label=f'Average Reward (window={window})')
        plt.xlabel('Episode')
        plt.ylabel('Reward')
        plt.title(f'{title} Learning Curve')
        plt.legend()
        
        # 平滑长度
        avg_lengths = np.convolve(lengths, np.ones(window)/window, mode='valid')
        plt.subplot(2, 1, 2)
        plt.plot(np.arange(len(lengths)), lengths, alpha=0.5, label='Episode Length')
        plt.plot(np.arange(window-1, len(lengths)), avg_lengths, label=f'Average Length (window={window})')
        plt.xlabel('Episode')
        plt.ylabel('Length')
        plt.title('Episode Length Over Time')
        plt.legend()
    else:
        plt.subplot(2, 1, 1)
        plt.plot(np.arange(len(rewards)), rewards, label='Episode Reward')
        plt.xlabel('Episode')
        plt.ylabel('Reward')
        plt.title(f'{title} Learning Curve')
        plt.legend()
        
        plt.subplot(2, 1, 2)
        plt.plot(np.arange(len(lengths)), lengths, label='Episode Length')
        plt.xlabel('Episode')
        plt.ylabel('Length')
        plt.title('Episode Length Over Time')
        plt.legend()
    
    plt.tight_layout()
    plt.savefig("learning_curves.png")
    plt.close()

def create_directories():
    """创建必要的目录"""
    directories = ['models', 'results']
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)

def create_video_buffer(env, agent, episodes=5, max_steps=1000, fps=10):
    """创建视频缓冲区"""
    from moviepy.editor import ImageSequenceClip
    import tempfile
    import os
    
    # 创建临时目录存储帧
    temp_dir = tempfile.mkdtemp()
    frames = []
    
    for episode in range(episodes):
        state = env.reset()
        done = False
        step = 0
        
        while not done and step < max_steps:
            # 渲染并保存帧
            env.render()
            pygame_surface = env.display
            
            # 将 PyGame surface 转换为 numpy 数组
            frame = np.array(pygame.surfarray.array3d(pygame_surface))
            frame = frame.transpose([1, 0, 2])  # 转置以获得正确的方向
            frames.append(frame)
            
            # 选择动作
            action, _ = agent.select_action(state, deterministic=True)
            state, reward, done, _ = env.step(action)
            step += 1
    
    env.close()
    
    # 创建视频剪辑并保存
    clip = ImageSequenceClip(frames, fps=fps)
    video_path = os.path.join('results', 'snake_ai.mp4')
    clip.write_videofile(video_path)
    
    return video_path